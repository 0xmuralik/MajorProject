import React,{Component, useState} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './LoginForm.css'
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';


class RegisterForm extends Component{


    constructor(){
        super()
        this.state={show:false
        }
        
    }
   


    selectedCities=(e)=>{
        this.setState({selectedCities:e.value});
    }

    render(props){
        return(
            <div class="wrapper wrapper--w720">
                <Card bg='light'>
                    <Card.Header>
                        Registration
                    </Card.Header>
                    <Card.Body>
                        <form onSubmit={this.submitHandler}>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="col-sm-8 label">Full Name</label>
                                            <input class="col-sm-8 input--style-4" name="name" type="text" value={this.state.name} onChange={this.nameHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="col-sm-8 label">Email ID</label>
                                            <input class="col-sm-8 input--style-4" name="email" type="text" value={this.state.email} onChange={this.emailHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="label col-sm-8">Contact No.</label>
                                            <input class="col-sm-8 input--style-4" name="contact" type="text" value={this.state.contact} onChange={this.contactHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="label col-sm-8">Description</label>
                                            <textarea class="col-sm-8 input--style-4" name="contact" type="text" value={this.state.description} onChange={this.descriptionHandler}/>
                                        </div>
                                    </div>
                                </div>

                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="col-sm-8 label">Password</label>
                                            <input class="col-sm-8 input--style-4" name="password" type="password" value={this.state.password} onChange={this.passwordHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="col-sm-8 label">Confirm Password</label>
                                            <input class="col-sm-8 input--style-4" name="confirmPassword" type="password" value={this.state.confirmPassword} onChange={this.confirmPasswordHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <Button variant='primary' type="submit">Submit</Button>
                                </div>
                        </form>
                    </Card.Body>
                </Card>
        </div>
        )
    }

    closeModal=()=>{
        this.setState({show:false})
    }

    openModal=()=>{
        this.setState({show:true})
    }
}
export default RegisterForm