import React, { Component } from 'react'
import {details} from '../Utils/ResearchDetails'
import ListGroup from 'react-bootstrap/ListGroup'
import Container from 'react-bootstrap/Container'
import Row from 'react-bootstrap/Row'
import ResearchCard from './ResearchCard'
export class ProcessResearchCards extends Component {

    constructor(props) {
        super(props);
        console.log(details)
        this.researchDetails=details;
    }

    render() {
        this.renderr=this.researchDetails.map((details) => (
            <Container >
                <Row className="justify-content-md-center">
                    <ListGroup horizontal={true} className="my-2" key={details.id}>
                    <ListGroup.Item><ResearchCard details={details}/></ListGroup.Item>
                    </ListGroup>
                </Row>
           
            </Container>
        ))
        return (
            <div >
                {this.renderr}
            </div>
        )
    }
}

export default ProcessResearchCards
