import React from "react";

function Author() {
  return <div>Display author details</div>;
}
export default Author;