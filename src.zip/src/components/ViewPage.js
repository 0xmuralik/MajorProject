
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Author from "./Author";

import Card from "react-bootstrap/Card";

function ViewPage() {
  const ContainerCss = {
    margin: "auto",
    width: "100%",
    border: "3px solid green",
    padding: "10px",
  };
  return (
    <Container style={ContainerCss}>
      <Row>State Research Portal</Row>
      <Card style={{ width: "100%" }}>
        <Row>LOREM IPSUM RESEARCH</Row>
        <Row>
          ABSTRACT:- Lorem ipsum dolor sit amet, consectetur adipiscing elit,
          sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
          enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.{" "}
        </Row>
        <Row>
          <Col>
            <Router>
              <Link to="/author" className="btn btn-primary">
                AuthorName
              </Link>
              <Switch>
                <Route path="/author">
                  <Author />
                </Route>
              </Switch>
            </Router>
          </Col>
          <Col>
            <p>Year</p>
          </Col>
          <Col>Likes</Col>
          <Col>Saved</Col>
        </Row>
        <Row>Papers</Row>
        <Row>Code</Row>

        <Row>KeyWords</Row>
      </Card>
    </Container>
  );
}

export default ViewPage;