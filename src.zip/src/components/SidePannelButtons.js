import React from 'react'
import { Link } from 'react-router-dom';
import './SidePannel.css';
import ListGroup from 'react-bootstrap/ListGroup';
function SidePannelButtons(props) {
    return (
        console.log(props.item),
        <li key={props.index} className={props.item.cName}>
                  <a data-toggle="collapse"  href="#children">
                    {props.item.icon}
                    <span>{props.item.title}</span>
                  </a>
                  <div id="children" class="collapse">
                  <ListGroup>
                      {props.item.children.map((child,index)=>{
                          return(
                              <SidePannelButtons item={child} index={index}/>
                          )
                      })}
                  </ListGroup>
                  </div>
        </li>

    )
}

export default SidePannelButtons
