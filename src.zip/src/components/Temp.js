import React,{Component} from 'react';
import LoginForm from './LoginForm'
import RegisterForm from './RegisterForm';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from 'react-bootstrap/Button'
import './Login.css'

class Temp extends Component {

    constructor(props){
        super(props)
        this.state={login:true,register:false};
    }

    showLogin=()=>{
        this.setState({login:true,register:false});
    }

    showRegister=()=>{
        this.setState({login:false,register:true});
    }

    render(){

        this.renderr=this.state.login?<LoginForm/>:<RegisterForm/>

        return(
            <div class='bg-gra-01 page-wrapper'>
                <Container>
                <Row>
                    <div class='col-sm-4 div-padding-20p'> 
                    <Col>
                       <Button onClick={this.showLogin}>LogIn</Button>
                       <Button onClick={this.showRegister}>Register</Button>
                    </Col>
                    </div>
                    <div class="col-sm-1 vl"></div>
                    <div class='col-sm-7 div-padding-70px'>
                    <Col>
                        {this.renderr}
                    </Col>
                    </div>
                </Row>
                
                </Container>
            </div>
        )
    }

}
export default Temp