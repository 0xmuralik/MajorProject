import React, { Component } from 'react'
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import SidePannel from './SidePannel';
import Navbar from 'react-bootstrap/Navbar';
import './Header.css';
export class Header extends Component {
    render() {
        return (
             <div class="fixed-top">
<Navbar class='navbar'   expand="lg">
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Container>
    <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="ml-auto">

        <Nav.Link >Home</Nav.Link>
        <Nav.Link >Notifications</Nav.Link>
        <Nav.Link >Profile</Nav.Link>
        <NavDropdown title='Settings'>
            <NavDropdown.Item>Settings</NavDropdown.Item>
            <NavDropdown.Item>Log Out</NavDropdown.Item>
        </NavDropdown>
    </Nav>
  </Navbar.Collapse>
  </Container>
</Navbar>
          
          </div>



        )
    }
}

export default Header
