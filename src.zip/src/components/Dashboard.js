import React, { Component } from 'react'
import FilterNavBar from './FilterNavBar'
import SearchBar from './SearchBar'
import ProcessResearchCards from './ProcessResearchCards';
import Header from './Header';
import SidePannel from './SidePannel';
import Container from 'react-bootstrap/Container';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import ViewPage from './ViewPage';

export class Dashboard extends Component {

    constructor(props) {
        super(props)
    }
    render() {
        console.log(this.props)
        return (
            <>
                <Header/>
                
                <div>
                    <Container>
                        <Row>
                            <Col sm={2}>
                                <div  style={{top:'600px'}}>
                                <SidePannel/>
                                </div>
                            
                            </Col>
                            <Col  sm={10}>
                                <div class="sticky-top" style={{top:'60px'}}>
                                    <FilterNavBar/>
                                </div>
                                <div  style={{position:'relative',top:'240px'}}>
                                    <ViewPage/>
                                </div>
                            </Col>
                        </Row>
                    </Container>
                </div>
                
            </>
        )
    }
}

export default Dashboard
