import React,{Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './LoginForm.css'
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button'
import Dashboard from './Dashboard';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
class LoginForm extends Component{


    constructor(props){
        super(props)
        this.state={email:"", password:""}
    }

    emailHandler = (event)=>{
        console.log(`${event.target.value}`)
        this.setState({email:event.target.value})
    }
    passwordHandler = (event)=>{
        console.log(`${event.target.value}`)
        this.setState({password:event.target.value})
    }
    submitHandler = ()=>{
        this.props.parentcallback(this.state)
    }
    

    render(props){
        return(
            <div class="wrapper wrapper--w360">
                <Card bg='light'>
                    <Card.Header>
                        Log In
                    </Card.Header>
                    <Card.Body>
                        <form onSubmit={this.submitHandler}>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="col-sm-8 label">Email ID</label>
                                            <input class="col-sm-8 input--style-4" name="email" type="text" value={this.state.email} onChange={this.emailHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <div >
                                        <div class="input-group">
                                            <label class="label col-sm-8">Password</label>
                                            <input class="col-sm-8 input--style-4" name="Password" type="password" value={this.state.password} onChange={this.passwordHandler}/>
                                        </div>
                                    </div>
                                </div>
                                <div >
                                    <Button variant='primary' type="submit">Submit</Button>
                                </div>
                        </form>
                    </Card.Body>
                </Card>
        </div>
        )
    }
}
export default LoginForm;