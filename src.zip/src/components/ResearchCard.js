import React, { Component } from 'react'
import Card from 'react-bootstrap/Card'
import ButtonGroup from 'react-bootstrap/ButtonGroup'
import ButtonToolbar from 'react-bootstrap/ButtonToolbar'
import Button from 'react-bootstrap/Button'
import Image from 'react-bootstrap/Image'
import Container from 'react-bootstrap/Container'
import Col from 'react-bootstrap/Col'
import Row from 'react-bootstrap/Row'
import rImg from '../Images/Rohith.JPG';
import AbstractModal from './AbstractModal';


import './LoginForm.css'
export class ResearchCard extends Component {

    constructor(props) {
        super(props);
        this.modalRef=React.createRef();
    }

    openAbstractModal=()=>{
        this.modalRef.current.openAbstractModal();
    }
    render() {
        return (
            <>
            <div  class="wrapper wrapper--w720">
               <Card >
                    <Card.Header style={{background:'#aeb9f7'}}>
                        <Container>
                            <Row>
                                <Col md={2}>
                                    <Image width="40" height="35" src={rImg} roundedCircle />   
                                </Col>
                                <Col md={8}>
                                    <Row>
                                        <h5>{this.props.details.author}</h5>
                                    </Row>
                                    <Row>
                                        <h6>27 April at 17:44  </h6>
                                    </Row>
                                </Col>
                            </Row>
                        </Container>
                    </Card.Header>
                    <Card.Body style={{background:'#d8dbf0'}}>
                        <Card.Title>{this.props.details.title}</Card.Title>
                        <Card.Subtitle>{this.props.details.status}</Card.Subtitle>
                        <Card.Link href="#">View</Card.Link>
                        <hr/>
                        <Card.Text>
                            {this.props.details.abstract}
                            <Card.Link onClick={this.openAbstractModal}>Read More</Card.Link>
                        </Card.Text>
                        
                        <div>
                            
                            <ButtonToolbar className="justify-content-between">
                            <ButtonGroup className='mr-2'>
                                <Button variant='primary'>Like</Button>
                            </ButtonGroup>
                            <ButtonGroup className='mr-2'>
                                <Button variant='primary'>Save</Button>
                            </ButtonGroup>
                            </ButtonToolbar>
                        </div>
                        </Card.Body> 
                    </Card>
            </div>
            <AbstractModal title={this.props.details.title} abstract={this.props.details.abstract} ref={this.modalRef}/>
            </>
        )
    }
}

export default ResearchCard
