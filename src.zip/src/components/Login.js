import React,{Component} from 'react';
import LoginForm from './LoginForm'
import RegisterForm from './RegisterForm';
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from 'react-bootstrap/Button'
import './Login.css'

class Login extends Component{

    constructor(props){
        super(props)
        this.regRef=React.createRef()
    }

    render(props){
        let shouldRegisterFormVisible
        return(
            <div class='bg-gra-01 page-wrapper'>
                <Container>
                <Row>
                    <div class='col-sm-4 div-padding-20p'> 
                    <Col>
                        <LoginForm parentcallback={this.props.parentcallback}/>
                    </Col>
                    </div>
                    <div class="col-sm-1 vl"></div>
                    <div class='col-sm-7 div-padding-70px'>
                    <Col><RegisterForm ref={this.regRef} /></Col>
                    </div>
                </Row>
                
                </Container>
            </div>

            // <div>
            //     <LoginForm parentcallback={this.props.parentcallback}/>
            //     <button onClick={this.registerHandler}>Register</button>
            //     <RegisterForm ref={this.regRef}/>
            // </div>
        )
    }
    registerHandler=()=>{
        this.regRef.current.openModal()
    }
}
export default Login