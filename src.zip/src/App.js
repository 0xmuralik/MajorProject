import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Temp from './components/Temp';
import React, { Component } from 'react';
import SearchBar from './components/SearchBar';
import "jquery/dist/jquery.min.js";
import "bootstrap/dist/js/bootstrap.min.js";
import'bootstrap/dist/css/bootstrap.css';
import {BrowserRouter as Router,Switch,Route,Link, useLocation } from "react-router-dom";

class App extends Component{
  constructor(props){
    super(props)
    this.state={password:'',email:''}
  this.handlecallback=this.handlecallback.bind(this);
  }

  handlecallback=(childValues)=>{
    console.log(childValues)
    this.setState({password:childValues.password,email:childValues.email})

  }
  render(){
    this.page=this.state.email==''?<Login parentcallback = {this.handlecallback} />:<Dashboard email={this.state.email} password={this.state.password}/>
    return (
      <Router>

      <div >
        {this.page}
      </div>
      </Router>
    );
  }
}

export default App;
