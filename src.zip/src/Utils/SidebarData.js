import React from 'react';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as IoIcons from 'react-icons/io';
import * as CgIcons from 'react-icons/cg';

export const SidebarData = [
  {
    title: 'Home',
    path: '/',
    children:[],
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: 'Your Researches',
    path: '/reports',
    children:[
      {
        title:'Completed',
        path:'/',
        children:[],
        icon:<IoIcons.IoIosDoneAll/>,
        cName: 'nav-text'
      },
      {
        title:'Pending',
        path:'/',
        children:[],
        icon:<AiIcons.AiOutlineQuestion/>,
        cName: 'nav-text'
      }
    ],
    icon: <IoIcons.IoMdPhotos />,
    cName: 'nav-text'
  },
  {
    title: 'Saved',
    path: '/reports',
    children:[
      {
        title:'Completed',
        path:'/',
        children:[],
        icon:<IoIcons.IoIosDoneAll/>,
        cName: 'nav-text'
      },
      {
        title:'Pending',
        path:'/',
        children:[],
        icon:<AiIcons.AiOutlineQuestion/>,
        cName: 'nav-text'
      }
    ],
    icon: <FaIcons.FaSave />,
    cName: 'nav-text'
  },
  {
    title: 'Communities',
    path: '/team',
    children:[],
    icon: <CgIcons.CgCommunity />,
    cName: 'nav-text'
  },
  {
    title: 'Support',
    path: '/support',
    children:[],
    icon: <IoIcons.IoMdHelpCircle />,
    cName: 'nav-text'
  }
];