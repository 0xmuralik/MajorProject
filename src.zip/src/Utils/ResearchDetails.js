export const details=[
    {
        id:1,
        author:"Anna",
        title:"Mammogram",
        abstract:"Mammography is one of the most\
         common medical imaging examinations for \
         detecting cancers at an early stage. \
         -tissue lesions including masses, structural\
          distortions, and asymmetries are the most \
          common signs in breast cancer.",
        status:"Pending"
    },
    {
       id:2,
       author:"Kingu",
       title:"HER2",
       abstract:"Mammography is one of the most\
        common medical imaging examinations for \
        detecting cancers at an early stage. \
        -tissue lesions including masses, structural\
         distortions, and asymmetries are the most \
         common signs in breast cancer.",
       status:"Completed"
    },
    {
       id:3,
       author:"Thala",
       title:"Mitosis",
       abstract:"Mammography is one of the most\
        common medical imaging examinations for \
        detecting cancers at an early stage. \
        -tissue lesions including masses, structural\
         distortions, and asymmetries are the most \
         common signs in breast cancer.",
       status:"Completed"
    },
    {
      id:4,
      author:"Thala",
      title:"Mitosis",
      abstract:"Mammography is one of the most\
       common medical imaging examinations for \
       detecting cancers at an early stage. \
       -tissue lesions including masses, structural\
        distortions, and asymmetries are the most \
        common signs in breast cancer.",
      status:"Completed"
   },
   {
    id:5,
    author:"Thala",
    title:"Mitosis",
    abstract:"Mammography is one of the most\
     common medical imaging examinations for \
     detecting cancers at an early stage. \
     -tissue lesions including masses, structural\
      distortions, and asymmetries are the most \
      common signs in breast cancer.",
    status:"Completed"
 },
 {
  id:6,
  author:"Thala",
  title:"Mitosis",
  abstract:"Mammography is one of the most\
   common medical imaging examinations for \
   detecting cancers at an early stage. \
   -tissue lesions including masses, structural\
    distortions, and asymmetries are the most \
    common signs in breast cancer.",
  status:"Completed"
}
];
