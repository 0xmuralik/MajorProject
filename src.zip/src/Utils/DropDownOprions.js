export const options=[
    {
        title:"Domain",
        fields:[
            {option:"Artificial Intelligence"},
            {option:"Block Chain"},
            {option:"Augmented Reality"},
            {option:"Wep Application"},
            {option:"Mobile Application"}
        ],
        id:1
    },
    {
        title:"Researcher Type",
        fields:[
            {option:"Private Researcher"},
            {option:"R&D Labs"}
        ],
        id:2
    },
    {
        title:"Status",
        fields:[
            {option:"Pending"},
            {option:"Completed"}
        ],
        id:3
    },
    {
        title:"Author",
        fields:[
            {option:"Kingu"},
            {option:"Anna"},
            {option:"Thala"},
        ],
        id:3
    }

];